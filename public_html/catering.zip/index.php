<?php error_reporting(E_ERROR | E_PARSE); ?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>VASQUEZ CATERING</title>
	<!-- Mobile Specific Metas
  ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!-- CSS
  ================================================== -->
	<!-- Bootstrap -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<!-- FontAwesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!--    flaticon-->
	<link rel="stylesheet" type="text/css" href="css/flaticon.css">
	<!-- Animation -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Template styles-->
	<link rel="stylesheet" href="css/style.css">
	<!-- Responsive styles-->
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
  

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body data-spy="scroll" data-target=".navigation" data-offset="20">
     
	<!-- section-top start -->
	<section>
		<div class="container">
			<div class="row">
				<div class="page-top">
					<!-- Inner -->
					<div class="pagetop_inner clearfix">
						<!-- Left Text -->
						<div class="f-left texts">
							<!-- Text -->
							<p> Welcome to VASQUEZ CATERING! We love to serve delicious food! </p>
						</div>
						<!-- Socials -->
						<div class="f-right socials">
							<p>Opening hours : <span>Mon-Sun : 9:00 - 18:00</span></p>
						</div>
						<!-- End Socials -->
					</div>
				</div>
				<!-- End Inner -->
			</div>
		</div>
	</section>
	<!-- section-top end -->
	
	<!-- navigation start -->
	<section class="navbar navbar-custom navbar-main main-nav" id="section-header">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
						<div class="navbar-brand">
							<a href="index.php" class=" scroll"> <img src="images/logo.png" alt="" class="img-responsive scroll"> </a>
						</div>
					</div>
					<!-- /navbar-header end -->
					<nav class="navbar-collapse collapse navbar-main navbar-main-collapse navbar-right navigation">
						<ul class="nav navbar-nav ">
							<li><a href="#para" class="active scroll">Home</a></li>
							<li><a href="#section-welcome" class="scroll">Our Story</a></li>
                                                        <li><a href="#section-special" class="scroll">Events</a></li>
                                                        <li class="dropdown nav-item">
                                                        <a class="nav-link text-white dropdown-toggle"  data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                                        Menu 
                                                        </a>
                                                        <ul class="collapse" id="collapseExample">
                                                          
                                                        <li><a  href="#" aria-controls="tab-c" role="tab" data-toggle="tab" class="scroll dropmenu socio">Social Event</a></li>
                                                        <li><a  href="#" class="scroll dropmenu wedding">Wedding  Event</a></li>
                                                        <li><a  href="#" aria-controls="tab-d" role="tab" data-toggle="tab" class="scroll dropmenu corpor">Corporate  Event</a></li>
                                                       
                                                        </ul>
                                                        </li>
                                                        
                                                        <li><a href="#section-testi" class="scroll">Reviews</a></li>
							<li><a href="#section-reservation" class="scroll">Contact Us</a></li>
						</ul>
					</nav>
					<!-- col end -->
				</div>
			</div>
		</div>
		<!-- conatiner end -->
	</section>
	<!-- navigation end -->
	
	<!-- Slider start -->
        <div id="section-banner" >
		
	</div>
	<!-- Slider end-->
	
	<!-- Section welcome start-->
	<section id="section-welcome" class="section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="section-heading wow pulse">
						<h2>Our Story</h2>
						<h3>know more about us</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae animi illo veniam eos unde laborum doloribus quo accusantium dolores fugit quod.</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<div class="item active">
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="welcome-img"> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive"> </div>
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="about-content">
									<h4>we offer quality food </h4>
									<h3 class="section-title">Your satisfaction is our main priority.</h3>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis quidem voluptas repudiandae error provident. Dicta ducimus praesentium impedit. Expedita, veritatis. Dolorum commodi cum atque id deserunt quis non voluptatum autem.</p>
								</div>
							</div>
						</div>
						<!-- item end  -->
						<div class="item ">
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="welcome-img"> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive"> </div>
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="about-content">
									<h4>we offer Nice environment</h4>
									<h3 class="section-title">Delicious Food made in nice environment</h3>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis quidem voluptas repudiandae error provident. Dicta ducimus praesentium impedit. Expedita, veritatis. Dolorum commodi cum atque id deserunt quis non voluptatum autem.</p>
								</div>
							</div>
						</div>
						<!-- item end  -->
						<div class="item ">
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="welcome-img"> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive"> </div>
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="about-content">
									<h4>Food made with care</h4>
									<h3 class="section-title">Delicious Food made in nice environment</h3>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis quidem voluptas repudiandae error provident. Dicta ducimus praesentium impedit. Expedita, veritatis. Dolorum commodi cum atque id deserunt quis non voluptatum autem.</p>
								</div>
							</div>
						</div>
						<!-- item end  -->
					</div>
				</div>
			</div>
			<!-- row end -->
		</div>
		<!-- container end -->
	</section>
	<!-- Section Welcome end-->
	
	<!-- Section Feature start-->
	<section id="section-feature">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-6 wow fadeInUp">
					<div class="feature-box"> <a href="#"><i class="flaticon flaticon-dinner-1"></i></a>
						<h4>Nice Environment</h4>
						<p>Reprehenderit molestias similique doloremque saepe.</p>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 wow fadeInUp" data-wow-delay=".3s">
					<div class="feature-box"> <a href="#"><i class="flaticon flaticon-delivery"></i></a>
						<h4>Home Delivery</h4>
						<p>Reprehenderit molestias similique doloremque saepe.</p>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 wow fadeInUp" data-wow-delay=".6s">
					<div class="feature-box"> <a href="#"><i class="flaticon flaticon-cooker"></i></a>
						<h4>Qualified Cook</h4>
						<p>Reprehenderit molestias similique doloremque saepe.</p>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 wow fadeInUp" data-wow-delay=".9s">
					<div class="feature-box"> <a href="#"><i class="flaticon flaticon-open"></i></a>
						<h4>Always Available</h4>
						<p>Reprehenderit molestias similique doloremque saepe.</p>
					</div>
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!--  section-Feature end    -->
	
	<!--  section-service start    -->
	<section id="section-services" class="section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="section-heading wow fadeInDown">
						<h2>our services</h2>
						<h3>what we deliver for you</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae animi illo veniam eos unde laborum doloribus quo accusantium dolores fugit quod.</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-7 col-sm-12">
					<div class="row wow fadeInLeft">
						<div class="col-md-12">
							<div class="service-box">
								<div class="service-img" > <img src="images/bg/gray_background_image.png" alt="" class="img-responsive"> </div>
								<div class="service-content ">
									<h4>breakfast</h4>
									<p>Atque voluptatum earum, tenetur vel totam vitae commodi esse corporis ea consequatur veritatis! Dolor ex non velit?</p>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="service-box">
								<div class="service-img "> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive"> </div>
								<div class="service-content ">
									<h4>Launch</h4>
									<p>Atque voluptatum earum, tenetur vel totam vitae commodi esse corporis ea consequatur veritatis! Dolor ex non velit?</p>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="service-box">
								<div class="service-img "> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive"> </div>
								<div class="service-content ">
									<h4>Dinner</h4>
									<p>Atque voluptatum earum, tenetur vel totam vitae commodi esse corporis ea consequatur veritatis! Dolor ex non velit?</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-5 col-sm-5 hidden-xs hidden-sm wow slideInRight"> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive"> </div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!--  section-service end    -->
	<?php  
         include_once 'database.php';
         $result = mysqli_query($conn,"select * From reviews ORDER BY revid desc LIMIT 10");
         if (mysqli_num_rows($result) > 0) {
             $count= mysqli_num_rows($result);
            
         ?>
	<!--  section-testimonial start    -->
	<section id="section-testi" class="section-padding">
		<div class="container">
			<div class="row">
				<div class="carousel slide" id="testimonial-carousel" data-ride="carousel">
					<!-- Indicators -->
                                 
					<ol class="carousel-indicators">
                                            <?php   for($b=0;$b<$count;$b++) { if($b ==0 ){$activec='class="active"'; }else{$activec='';} ?>
						<li data-target="#testimonial-carousel" data-slide-to="<?= $b?>"  <?= $activec ?> ></li>
						<?php  } ?>
                                             
					</ol>
                                             
					<div class="carousel-inner" role="listbox">
                                               <?php $i=0;  while($row = mysqli_fetch_array($result)) {    if($i ==0){$active='active'; }else{$active='';} ?>
                                               <div class="item <?= $active ?>">
                                                  <div class="testimonail-caption"> <i class="fa fa-quote-left"></i>
								<p><?php echo $row["feedback"]; ?></p>
								<div class="test-content">
									<h3>- <?php echo $row["name"]; ?></h3> </div>
							</div>
                                                   
						</div>
						 <?php $i++; } ?>
					</div>
                                   
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!--  section-testimonial end    -->
             <?php }else{ ?>
        <!--  section-testimonial start    -->
	<section id="section-testi" class="section-padding">
		<div class="container">
			<div class="row">
				<div class="carousel slide" id="testimonial-carousel" data-ride="carousel">
					<!-- Indicators -->
					<ol class="carousel-indicators">
						<li data-target="#testimonial-carousel" data-slide-to="0" class="active"></li>
						<li data-target="#testimonial-carousel" data-slide-to="1"></li>
						<li data-target="#testimonial-carousel" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner" role="listbox">
						<div class="item active">
							<div class="testimonail-caption"> <i class="fa fa-quote-left"></i>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati eveniet rerum, blanditiis ex quasi reprehenderit itaque error mollitia eligendi at in quaerat. Error molestias voluptatum assumenda similique, deserunt, rem minus!</p>
								<div class="test-content">
									<h3>- joe adam</h3> </div>
							</div>
						</div>
						<div class="item ">
							<div class="testimonail-caption"> <i class="fa fa-quote-left"></i>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati eveniet rerum, blanditiis ex quasi reprehenderit itaque error mollitia eligendi at in quaerat. Error molestias voluptatum assumenda similique, deserunt, rem minus!</p>
								<div class="test-content">
									<h3>- martin adam</h3> </div>
							</div>
						</div>
						<div class="item ">
							<div class="testimonail-caption"> <i class="fa fa-quote-left"></i>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati eveniet rerum, blanditiis ex quasi reprehenderit itaque error mollitia eligendi at in quaerat. Error molestias voluptatum assumenda similique, deserunt, rem minus!</p>
								<div class="test-content">
									<h3>- lora defil</h3> </div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!--  section-testimonial end    --> <?php
        } ?>
	
	<!--  section-Menu start    -->
	<section id="section-menu" class="section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="section-heading">
						<h2>Menu</h2>
						<h3>VASQUEZ CATERING menubook </h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae animi illo veniam eos unde laborum doloribus quo accusantium dolores fugit quod.</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="menubook">
					<!-- Nav tabs -->
					<ul class="nav nav-tabs tab-justified" role="tablist" id="menu-tab">
						
                                            <li class="wed" role="presentation"><a href="#tab-b" aria-controls="tab-b" role="tab" data-toggle="tab">Wedding</a></li>
						<li  role="presentation" class="active soc"><a href="#tab-c" aria-controls="tab-c" role="tab" data-toggle="tab">Social</a></li>
						<li class="cor" role="presentation"><a href="#tab-d" aria-controls="tab-d" role="tab" data-toggle="tab">Corporate</a></li>
						
					</ul>
					<!-- Tab panes -->
					<div class="tab-content">
						
						
						<div role="tabpanel" class="tab-pane fade" id="tab-b">
							<div class="col-md-12 col-sm-12 wow fadeInLeft">
                                                            <div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Mexican</h2></div>
								</div>
                                                                <div class="menu-item"> 
									<div class="menu-inner">
                                                                            <h4 class="h4under">Chicken Fried Salad <span >10$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12  wow fadeInRight">
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>10$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInLeft" data-wow-delay=".3s">
							<div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Italian</h2></div>
								</div>	
                                                            <div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>10$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInRight" data-wow-delay=".3s">
                                                            
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>10$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInLeft" data-wow-delay=".6s">
                                                              <div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Buffet</h2></div>
								</div>
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>10$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInRight" data-wow-delay=".6s">
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>10$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
						</div>
						
						<div role="tabpanel" class="tab-pane fade in active" id="tab-c">
							<div class="col-md-12 col-sm-12 wow fadeInLeft">
								<div class="menu-item"> 
                                                                      <div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Mexican</h2></div>
								</div>
									<div class="menu-inner">
                                                                            <h4 class="h4under">Chicken Fried Salad <span >20$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12  wow fadeInRight">
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>20$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInLeft" data-wow-delay=".3s">
                                                              <div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Italian</h2></div>
								</div>
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>20$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInRight" data-wow-delay=".3s">
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>20$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInLeft" data-wow-delay=".6s">
                                                              <div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Buffet</h2></div>
								</div>
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>20$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInRight" data-wow-delay=".6s">
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>20$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
						</div>
						
						<div role="tabpanel" class="tab-pane fade" id="tab-d">
							<div class="col-md-12 col-sm-12 wow fadeInLeft">
                                                              <div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Mexican</h2></div>
								</div>
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>30$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12  wow fadeInRight">
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>30$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInLeft" data-wow-delay=".3s">
                                                              <div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Italian</h2></div>
								</div>
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>30$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInRight" data-wow-delay=".3s">
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>30$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInLeft" data-wow-delay=".6s">
                                                              <div class="menu-item" style="padding-bottom: 0px !important;"> 
									<div class="menu-inner">
                                                                            <h2 class="h3under">Buffet</h2></div>
								</div>
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>30$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
							<div class="col-md-12 col-sm-12 wow fadeInRight" data-wow-delay=".6s">
								<div class="menu-item"> 
									<div class="menu-inner">
										<h4 class="h4under">Chicken Fried Salad <span>30$</span></h4> </div>
									<p> Aperiam tempore sit,perferendis numquam repudiandae porro voluptate dicta saepe facilis.</p>
								</div>
							</div>
						</div>
						
						
					</div>
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!--  section-Menu end    -->
	
        <!--  section-add-review start    -->
	<section id="section-rev" class="section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="section-heading wow fadeInDown">
                                            <h2 style="color:#fff">WE APPRECIATE YOUR REVIEW!</h2>
						<h3>Your review will help us to improve our web hosting quality products, and customer services.</h3>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 wow fadeInUp">
					 <form action="index.php" id="contact-form" role="form" method="post">
						
                                                <div class="col-md-6 col-sm-6">
						<div class="form-group" id="name-field">
								<input class="form-control contact-form-field cffield-upper" name="fname" id="form-name" placeholder="Your name" type="text" required> </div>
						</div>
						<div class="col-md-6 col-sm-6">
							<div class="form-group" id="email-field">
								<input class="form-control contact-form-field cffield-upper" name="femail" id="form-email" placeholder="Your email" type="email" required> </div>
						</div>
                                              
                                                <div class="col-md-12">
							<div class="form-group form-text text-center" id="message-field">
								<textarea cols="30" rows="6" placeholder="Your feedback" class="form-control contact-form-field" name="fmessage" id="form-message" required></textarea>
							</div>
						</div>
						<div class="col-md-12 text-center">
                                                    <input  type="submit" value="Submit" name="btn"  class="btn btn-primary feature" >
							
						</div>
					</form>
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!--  section-Reservation end    -->
        
        <!-- section special menu event    -->
	<section id="section-special" class="section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="section-heading wow pulse">
						<h2>Special Events</h2>
						<h3>Special organisation for you </h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae animi illo veniam eos unde laborum doloribus quo accusantium dolores fugit quod.</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-4 wow fadeInUp">
					<div class="events-box"> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive">
						<div class="event-content">
							<h4>Wedding event</h4>
							<p>Eveniet eius obcaecati nihil earum sed voluptate, non, omnis quisquam totam rerum veniam nostrum quidem dolores iste.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay=".3s">
					<div class="events-box"> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive">
						<div class="event-content">
							<h4>Corporate Meeting</h4>
							<p>Eveniet eius obcaecati nihil earum sed voluptate, non, omnis quisquam totam rerum veniam nostrum quidem dolores iste.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay=".5s">
					<div class="events-box"> <img src="images/bg/gray_background_image.png" alt="" class="img-responsive">
						<div class="event-content">
							<h4>Special Party</h4>
							<p>Eveniet eius obcaecati nihil earum sed voluptate, non, omnis quisquam totam rerum veniam nostrum quidem dolores iste.</p>
						</div>
					</div>
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!-- section speciail menu event     End-->
        
        
	<!--  section-Contact start    -->
	<section id="section-reservation" class="section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="section-heading wow fadeInDown">
						<h2>Contact Us</h2>
						<h3>For all enquiries, Please email us using the form below</h3>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 wow fadeInUp">
					 <form action="index.php" id="contact-form" role="form" method="post">
						<div class="col-md-6 col-sm-6">
							<div class="form-group" id="name-field">
								<input class="form-control contact-form-field cffield-upper" name="fname" id="form-name" placeholder="Your name" type="text" required> </div>
						</div>
						<div class="col-md-6 col-sm-6">
							<div class="form-group" id="email-field">
								<input class="form-control contact-form-field cffield-upper" name="femail" id="form-email" placeholder="Your email" type="email" required> </div>
						</div>
						<div class="col-md-6 col-sm-6">
							<div class="form-group" id="mobile-field">
								<input class="form-control contact-form-field cffield-upper" name="fmobile" id="form-mobile" placeholder="Contact No" type="text" required> </div>
						</div>
                                             <div class="col-md-6 col-sm-6">
							<div class="form-group" id="person-field">
								<input class="form-control contact-form-field cffield-upper" name="fperson" id="form-person" placeholder="No of Guests" type="text" required> </div>
						</div>
						<div class="col-md-12">
							<div class="form-group form-text text-center" id="message-field">
								<textarea cols="30" rows="6" placeholder="Your message" class="form-control contact-form-field" name="fmessage" id="form-message" required></textarea>
							</div>
						</div>
						<div class="col-md-12 text-center">
                                                      <input  type="submit" value="Send data" name="contactbtn"  class="btn btn-primary feature" >
                                                    
						</div>
					</form>
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!--  section-Reservation end    -->
	
	
	
	<!--    section footer start -->
	<section id="section-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4 wow fadeInDown">
					<div class="footer-content"> <img src="images/logo.png" alt="" class="img-responsive scroll logo">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis nulla commodi ut porro deserunt sapiente natus nihil consequatur.</p>
						<ul class="footer-social list-inline">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-4 col-sm-4 wow fadeInDown">
					<div class="footer-contact">
						<ul>
							<li><a href="#"><i class="fa fa-phone"></i> (408) 332-9827</a></li>
							<li><a href="#"><i class="fa fa-globe"></i> vasquez-catering.com</a></li>
							<li><a href="#"><i class="fa fa-envelope-o"></i> vasquezcatering@yahoo.com</a></li>
							
						</ul>
					</div>
				</div>
				<div class="col-md-4 col-sm-4 wow fadeInDown">
					<div class="footer-widget">
						<ul class="list-inline">
							<li>
								<a href="#"><img src="images/bg/gray_background_image.png" alt="" class="img-responsive"></a>
							</li>
							<li>
								<a href="#"><img src="images/bg/gray_background_image.png" alt="" class="img-responsive"></a>
							</li>
							<li>
								<a href="#"><img src="images/bg/gray_background_image.png" alt="" class="img-responsive"></a>
							</li>
							<li>
								<a href="#"><img src="images/bg/gray_background_image.png" alt="" class="img-responsive"></a>
							</li>
							<li>
								<a href="#"><img src="images/bg/gray_background_image.png" alt="" class="img-responsive"></a>
							</li>
							<li>
								<a href="#"><img src="images/bg/gray_background_image.png" alt="" class="img-responsive"></a>
							</li>
						</ul> 
					</div>
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</section>
	<!--    section footer end -->
	
	<!-- Footer start    -->
	<footer id="footer-btm">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-sm-5 wow fadeInLeft">
					<div class="copyright"> <a href="#" class="copy">&copy; Copyright Reserved to VASQUEZ CATERING.2021</a> </div>
				</div>
				<div class="col-md-7 col-sm-7 wow fadeInRight ">
					<div class="footer-menu pull-right">
						<ul class="list-inline">
							<li><a href="#para" class="active scroll">Home</a></li>
							<li><a href="#section-welcome" class="scroll">Our Story</a></li>
                                                        <li><a href="#section-special" class="scroll">Events</a></li>
                                                        
                                                        <li class="dropdown nav-item">
                                                        <a class="nav-link text-white dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        Menu 
                                                        </a>
                                                        <ul class="dropdown-menu dropdown-menu-right footermenu" aria-labelledby="dropdownMenuLink">
                                                         <li><a  href="#" aria-controls="tab-c" role="tab" data-toggle="tab" class="scroll dropmenu socio">Social Event</a></li>
                                                        <li><a  href="#" class="scroll dropmenu wedding">Wedding Event</a></li>
                                                        <li><a  href="#" aria-controls="tab-d" role="tab" data-toggle="tab" class="scroll dropmenu corpor">Corporate Event</a></li>
                                                        </ul>
                                                        </li>
                                                        
                                                        <li><a href="#section-testi" class="scroll">Reviews</a></li>
							<li><a href="#section-reservation" class="scroll">Contact Us</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!--    row end -->
		</div>
		<!--    container end -->
	</footer>
	<!-- Footer end    -->
	
	<!-- Page back to top -->
	<div id="back-to-top" data-spy="affix" data-offset-top="10" class="back-to-top affix"> <a class="btn btn-primary scroll" href="#section-banner" title="Back to Top"><i class="fa fa-angle-double-up"></i></a> </div>
	
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<!-- initialize jQuery Library -->
	<script type="text/javascript" src="js/jquery.js"></script>
	<!-- Bootstrap jQuery -->
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<!-- Wow Animation -->
	<script type="text/javascript" src="js/wow.min.js"></script>
	<!-- Eeasing -->
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<!-- Sticky JS -->
	<script type="text/javascript" src="js/jquery.sticky.js"></script>
	<!-- Waypoints -->
	<script type="text/javascript" src="js/jquery.waypoints.min.js"></script>
	<!-- theme js	 -->
	<script type="text/javascript" src="js/custom.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  
        <script>$(document).ready(function() {
$(".wedding").click(function () {
    $(".soc").removeClass("active");
    $(".cor").removeClass("active");
    $(".wed").addClass("active");
    $('html, body').animate({scrollTop: $(".wed").offset().top}, 2000);
});

$(".corpor").click(function () {
    $(".soc").removeClass("active");
    $(".wed").removeClass("active");
    $(".cor").addClass("active");
    $('html, body').animate({scrollTop: $(".cor").offset().top}, 2000);
});

$(".socio").click(function () {
    $(".soc").addClass("active");
    $(".wed").removeClass("active");
    $(".cor").removeClass("active");
    $('html, body').animate({scrollTop: $(".soc").offset().top}, 2000);
});


});</script>
</body>

</html>

<?php
if(isset($_POST['btn'])){
    
    $name    = stripslashes(trim($_POST['fname']));
    $email   = stripslashes(trim($_POST['femail']));
    $feedback = stripslashes(trim($_POST['fmessage']));
   
    include_once 'database.php';
   
    $sql = "INSERT INTO reviews (name,email,feedback) VALUES ('$name','$email','$feedback')";
   
    if ($conn->query($sql) === TRUE) {
       $_SESSION['msg'] = 'Review Added Successfully!';
       
     header("Refresh:0");
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
        
}


if(isset($_POST['contactbtn'])) {
    
    $subjectPrefix = '[VASQUEZ CATERING]';
$emailTo       = 'vasquezcatering@yahoo.com';
$errors = array(); // array to hold validation errors
$data   = array(); // array to pass back data
    
    $name    = stripslashes(trim($_POST['fname']));
    $email   = stripslashes(trim($_POST['femail']));
    $mobile   = stripslashes(trim($_POST['fmobile']));
    $person   = stripslashes(trim($_POST['fperson']));
    $message = stripslashes(trim($_POST['fmessage']));
    if (empty($name)) {
        $errors['fname'] = 'Name is required.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['femail'] = 'Email is invalid.';
    }
   	 if (empty($mobile)) {
        $errors['fmobile'] = 'mobile is required.';
    }
     if (empty($person)) {
        $errors['fperson'] = 'person is required.';
    }
    if (empty($message)) {
        $errors['fmessage'] = 'Message is required.';
    }
    // if there are any errors in our errors array, return a success boolean or false
    if (!empty($errors)) {
        $data['success'] = false;
        $data['errors']  = $errors;
    } else {
        $subject = $subjectPrefix;
        $body    = '
            <strong>Name: </strong>'.$name.'<br />
            <strong>Email: </strong>'.$email.'<br />
            <strong>Contact no of Function: </strong>'.$mobile.'<br />
            <strong>No Of Guests: </strong>'.$person.'<br />
            <strong>Message: </strong>'.nl2br($message).'<br />
        ';
        $headers .= "Organization: Vasquez Catering\r\n";
        $headers .= "X-Priority: 3\r\n";
        $headers  = "MIME-Version: 1.1" . PHP_EOL;
        $headers .= "Content-type: text/html; charset=utf-8" . PHP_EOL;
        $headers .= "Content-Transfer-Encoding: 8bit" . PHP_EOL;
        $headers .= "Date: " . date('r', $_SERVER['REQUEST_TIME']) . PHP_EOL;
        $headers .= "Message-ID: <" . $_SERVER['REQUEST_TIME'] . md5($_SERVER['REQUEST_TIME']) . '@' . $_SERVER['SERVER_NAME'] . '>' . PHP_EOL;
        $headers .= "From: " . "=?UTF-8?B?".base64_encode($name)."?=" . "<$email>" . PHP_EOL;
        $headers .= "Return-Path: $emailTo" . PHP_EOL;
        $headers .= "Reply-To: $email" . PHP_EOL;
        $headers .= "X-Mailer: PHP/". phpversion() . PHP_EOL;
        $headers .= "X-Originating-IP: " . $_SERVER['SERVER_ADDR'] . PHP_EOL;
        mail($emailTo, "=?utf-8?B?" . base64_encode($subject) . "?=", $body, $headers);
        $data['success'] = true;
        $data['message'] = 'Congratulations. Your message has been sent successfully';
    }
    // return all our data to an AJAX call
//    echo json_encode($data);
	// Die with a success message
//die("<span class='success'>Success! Your message has been sent.</span>");
	
             //do your validation or something here
         $_SESSION['msg'] = 'Email Send Successfully!';
         header("Refresh:0");
}




?>
 <?php if (isset($_SESSION['msg']) && !empty($_SESSION['msg'])) { ?>
           <script>
              var php_var = "<?php echo $_SESSION['msg']; ?>";
              
              swal({
  title: "Success!",
  text: php_var,
  type: "success",
  timer: 5000,
  showConfirmButton: true
}, function(){
      window.location.href = "/index.php";
});
                  </script>
            <?php
            unset($_SESSION['msg']);
        }
        ?>